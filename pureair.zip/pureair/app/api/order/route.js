import { google } from "googleapis";
import { PRODUCT, validate } from "@/lib/config";
export const runtime = "nodejs";

export async function POST(req) {
  let b;
  try { b = await req.json(); } catch { return Response.json({ error: "Invalid request." }, { status: 400 }); }
  if (b.website) return Response.json({ ok: true }); // honeypot: bots fill the hidden field
  const errors = validate(b);
  if (Object.keys(errors).length) return Response.json({ errors }, { status: 422 });

  const quantity = Number(b.quantity);
  const total = quantity * PRODUCT.price; // computed server-side, never trusted from the client
  const order = {
    id: "PA-" + Date.now().toString(36).toUpperCase() + Math.random().toString(36).slice(2, 5).toUpperCase(),
    date: new Date().toISOString(), name: b.name.trim(), phone: b.phone.trim(),
    address: b.address.trim(), quantity, product: `${PRODUCT.name} (${PRODUCT.title})`, total, status: "New",
  };
  try {
    const auth = new google.auth.JWT({
      email: process.env.GOOGLE_CLIENT_EMAIL,
      key: process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
      scopes: ["https://www.googleapis.com/auth/spreadsheets"],
    });
    await google.sheets({ version: "v4", auth }).spreadsheets.values.append({
      spreadsheetId: process.env.GOOGLE_SHEET_ID,
      range: `${process.env.GOOGLE_SHEET_TAB || "Orders"}!A:J`,
      valueInputOption: "RAW", // RAW avoids spreadsheet formula injection
      requestBody: { values: [[order.id, order.date, order.name, order.phone, order.address, order.quantity,
        order.product, order.total, order.status, (b.notes || "").trim().slice(0, 300)]] },
    });
  } catch (err) {
    console.error("Sheets error:", err?.message);
    return Response.json({ error: "We couldn't save your order. Your details are still here, so please try again." }, { status: 502 });
  }
  return Response.json({ ok: true, order });
}
