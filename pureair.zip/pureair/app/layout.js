import { Bricolage_Grotesque, Figtree } from "next/font/google";
import "./globals.css";
const display = Bricolage_Grotesque({ subsets: ["latin"], variable: "--font-display", display: "swap" });
const body = Figtree({ subsets: ["latin"], variable: "--font-body", display: "swap" });
const url = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";

export const metadata = {
  metadataBase: new URL(url),
  title: "PureAir P1: portable mini air purifier for car, desk and bedside",
  description: "A pocket-sized air purifier powered over USB-C. Cleaner air where you actually spend your day. Order online with delivery to your door.",
  openGraph: { title: "PureAir P1 portable mini air purifier", description: "Cleaner air in your car, at your desk and by your bed.", type: "website" },
};
export const viewport = { width: "device-width", initialScale: 1, themeColor: "#10222f" };

export default function RootLayout({ children }) {
  return (<html lang="en" className={`${display.variable} ${body.variable}`}><body>{children}</body></html>);
}
