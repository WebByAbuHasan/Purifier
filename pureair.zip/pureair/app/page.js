import OrderButton from "@/components/OrderButton";
import OrderModal from "@/components/OrderModal";
import PurifierArt from "@/components/PurifierArt";
import { PRODUCT, SPECS, GUARANTEE, REVIEWS, money } from "@/lib/config";

const pains = [
  ["Stale car air", "Closed windows, traffic and a hot cabin. You breathe it for the whole commute."],
  ["Dusty desk", "Hours at the same spot, where dust and stuffy air collect around you."],
  ["Restless nights", "A shut-in bedroom makes it harder to settle."],
];
const benefits = [
  ["Small enough to carry", "Move it from car to desk to bedside without thinking about it."],
  ["Runs on USB-C", "Plug into a power bank, laptop or car charger. No special adapter."],
  ["Replaceable filter", "Swap the filter when it's due instead of replacing the whole unit."],
  ["Simple to use", "One button. Put it near you, switch it on, get on with your day."],
];
const faqs = [
  ["How do I pay?", "You pay when we confirm the order by phone, or on delivery. Nothing is charged on this page."],
  ["How long does delivery take?", "We confirm timing when we call you. Add a landmark or preferred time in the delivery notes."],
  ["Will it clean my whole house?", "No. It's a personal purifier for a small, close space such as a car, desk or bedside."],
  ["What if it arrives damaged?", GUARANTEE],
  ["How do I replace the filter?", "The filter is replaceable. Instructions come in the box."],
];

const Section = ({ id, className = "", children }) => (
  <section id={id} className={`px-5 py-16 sm:py-24 ${className}`}><div className="reveal mx-auto max-w-5xl">{children}</div></section>
);
const H2 = ({ children }) => <h2 className="font-display text-3xl font-bold leading-tight sm:text-4xl">{children}</h2>;

export default function Page() {
  return (
    <main>
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-ink/10 bg-chalk/90 px-5 py-3 backdrop-blur">
        <span className="font-display text-lg font-bold">PureAir</span>
        <OrderButton className="!px-5 !py-2 text-sm">Order now</OrderButton>
      </header>

      <section className="px-5 pb-16 pt-10 sm:pt-16">
        <div className="mx-auto grid max-w-5xl items-center gap-10 md:grid-cols-2">
          <div>
            <h1 className="font-display text-4xl font-extrabold leading-[1.05] sm:text-6xl">Cleaner air, wherever you sit.</h1>
            <p className="mt-5 max-w-md text-lg text-mute">The {PRODUCT.name} is a pocket-sized air purifier that runs on USB-C. Keep it in your car, on your desk or by your bed.</p>
            <div className="mt-7 flex flex-wrap items-center gap-5">
              <OrderButton>Order now</OrderButton>
              <p><span className="font-display text-3xl font-bold">{money(PRODUCT.price)}</span><br /><span className="text-sm text-mute">Pay when we confirm or on delivery</span></p>
            </div>
          </div>
          <div className="flex justify-center"><PurifierArt /></div>
        </div>
      </section>

      <Section id="problem" className="bg-ink text-white">
        <H2>The air near you is the air you breathe most.</H2>
        <div className="mt-10 grid gap-5 sm:grid-cols-3">
          {pains.map(([t, d]) => <div key={t} className="rounded-2xl bg-white/10 p-6"><h3 className="font-display text-xl font-semibold">{t}</h3><p className="mt-2 text-white/75">{d}</p></div>)}
        </div>
      </Section>

      <Section id="solution">
        <div className="grid items-center gap-10 md:grid-cols-2">
          <div><H2>A small purifier for the small spaces you live in.</H2>
            <p className="mt-4 text-mute">Big purifiers clean a room. The P1 is for the few feet around you. It's light enough to move with you and simple enough to forget about once it's on.</p></div>
          <dl className="divide-y divide-ink/10 rounded-2xl bg-air px-6">
            {SPECS.map(([k, v]) => <div key={k} className="flex justify-between gap-4 py-4"><dt className="text-mute">{k}</dt><dd className="text-right font-medium">{v}</dd></div>)}
          </dl>
        </div>
      </Section>

      <Section id="benefits" className="bg-air">
        <H2>What you get</H2>
        <div className="mt-10 grid gap-5 sm:grid-cols-2">
          {benefits.map(([t, d], i) => (
            <div key={t} className={`rounded-3xl p-7 ${i === 0 ? "bg-ink text-white" : "bg-white"}`}>
              <h3 className="font-display text-xl font-bold">{t}</h3><p className={`mt-2 ${i === 0 ? "text-white/75" : "text-mute"}`}>{d}</p>
            </div>))}
        </div>
        <div className="mt-10 text-center"><OrderButton>Order the PureAir P1</OrderButton></div>
      </Section>

      <Section id="how">
        <H2>Set up in three steps</H2>
        <ol className="mt-10 grid gap-5 sm:grid-cols-3">
          {["Plug in with USB-C", "Place it within arm's reach", "Press the button and carry on"].map((s, i) => (
            <li key={s} className="rounded-2xl border border-ink/15 p-6"><span className="font-display text-3xl font-bold text-sun">{i + 1}</span><p className="mt-2 font-medium">{s}</p></li>))}
        </ol>
      </Section>

      <Section id="reviews" className="bg-sage/40">
        <H2>What customers say</H2>
        {REVIEWS.length ? (
          <div className="mt-8 grid gap-5 sm:grid-cols-2">{REVIEWS.map((r) => <figure key={r.name} className="rounded-2xl bg-white p-6"><blockquote>{r.text}</blockquote><figcaption className="mt-3 text-sm text-mute">{r.name}, {r.city}</figcaption></figure>)}</div>
        ) : (
          <p className="mt-4 max-w-lg text-mute">We're a new product and would rather show you real reviews than invented ones. They'll appear here as customers send them in.</p>
        )}
      </Section>

      <Section id="guarantee">
        <div className="rounded-3xl bg-ink p-8 text-white sm:p-12">
          <H2>If something's wrong, we fix it.</H2>
          <p className="mt-4 max-w-xl text-white/80">{GUARANTEE}</p>
        </div>
      </Section>

      <Section id="offer" className="bg-air">
        <div className="mx-auto max-w-md rounded-3xl bg-white p-8 text-center shadow-xl">
          <p className="text-mute">{PRODUCT.title}</p>
          <p className="font-display text-5xl font-extrabold">{money(PRODUCT.price)}</p>
          <ul className="my-6 space-y-2 text-left text-mute"><li>✓ PureAir P1 purifier with filter</li><li>✓ Confirmation call before dispatch</li><li>✓ Pay when confirmed or on delivery</li></ul>
          <OrderButton className="w-full">Order now</OrderButton>
        </div>
      </Section>

      <Section id="faq">
        <H2>Questions</H2>
        <div className="mt-8 divide-y divide-ink/10 border-y border-ink/10">
          {faqs.map(([q, a]) => (
            <details key={q} className="group py-4"><summary className="flex cursor-pointer list-none justify-between gap-4 font-medium">{q}<span className="transition group-open:rotate-45">+</span></summary><p className="mt-2 max-w-xl text-mute">{a}</p></details>))}
        </div>
      </Section>

      <section className="bg-ink px-5 py-20 text-center text-white">
        <h2 className="font-display text-3xl font-bold sm:text-4xl">Ready for cleaner air at your seat?</h2>
        <OrderButton className="mt-8">Order the PureAir P1</OrderButton>
      </section>
      <footer className="px-5 py-8 text-center text-sm text-mute">© {new Date().getFullYear()} PureAir. Personal purifier, not a medical device.</footer>
      <OrderModal />
    </main>
  );
}
