"use client";
import { useEffect, useRef, useState } from "react";
import { PRODUCT, money, validate } from "@/lib/config";

const empty = { name: "", phone: "", address: "", quantity: 1, notes: "", website: "" };
const input = "w-full rounded-xl border border-ink/20 bg-white px-4 py-3 text-base focus:border-ink";

function Field({ label, error, id, children, hint }) {
  return (
    <div>
      <label htmlFor={id} className="mb-1 block text-sm font-medium">{label}</label>
      {children}
      {hint && !error && <p className="mt-1 text-xs text-mute">{hint}</p>}
      {error && <p id={`${id}-err`} role="alert" className="mt-1 text-sm text-red-700">{error}</p>}
    </div>
  );
}

export default function OrderModal() {
  const ref = useRef(null), busy = useRef(false);
  const [f, setF] = useState(empty);
  const [errors, setErrors] = useState({});
  const [state, setState] = useState("idle"); // idle | loading | error | success
  const [msg, setMsg] = useState("");
  const [order, setOrder] = useState(null);
  const total = (Number(f.quantity) || 0) * PRODUCT.price;

  useEffect(() => {
    const open = () => ref.current?.showModal();
    window.addEventListener("open-order", open);
    return () => window.removeEventListener("open-order", open);
  }, []);

  const set = (k) => (e) => { setF({ ...f, [k]: e.target.value }); if (errors[k]) setErrors({ ...errors, [k]: undefined }); };
  const close = () => { ref.current?.close(); if (state === "success") { setF(empty); setOrder(null); setState("idle"); } };

  async function submit(e) {
    e.preventDefault();
    if (busy.current) return; // blocks double submits
    const v = validate(f);
    setErrors(v);
    if (Object.keys(v).length) { document.getElementById(`f-${Object.keys(v)[0]}`)?.focus(); return; }
    busy.current = true; setState("loading"); setMsg("");
    try {
      const res = await fetch("/api/order", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
      const data = await res.json().catch(() => ({}));
      if (res.status === 422 && data.errors) { setErrors(data.errors); setState("idle"); }
      else if (!res.ok) throw new Error(data.error);
      else { setOrder(data.order); setState("success"); }
    } catch (err) {
      setMsg(err.message || "Network problem. Check your connection and try again."); setState("error"); // form data is kept
    } finally { busy.current = false; }
  }

  return (
    <dialog ref={ref} aria-labelledby="order-title" onClick={(e) => e.target === ref.current && close()}
      className="m-auto w-[min(32rem,calc(100%-1.5rem))] rounded-3xl bg-chalk p-0 text-ink shadow-2xl">
      <div className="max-h-[90vh] overflow-y-auto p-6 sm:p-8">
        <div className="mb-4 flex items-start justify-between gap-4">
          <h2 id="order-title" className="font-display text-2xl font-bold">{state === "success" ? "Order received" : "Confirm your order"}</h2>
          <button onClick={close} aria-label="Close" className="rounded-full p-2 hover:bg-air">✕</button>
        </div>

        {state === "success" ? (
          <div role="status">
            <p className="text-mute">Thanks, {order.name}. We'll call {order.phone} to confirm delivery.</p>
            <dl className="mt-5 grid grid-cols-[auto_1fr] gap-x-6 gap-y-2 rounded-2xl bg-air p-5 text-sm">
              <dt className="text-mute">Order ID</dt><dd className="font-semibold">{order.id}</dd>
              <dt className="text-mute">Product</dt><dd>{PRODUCT.name} × {order.quantity}</dd>
              <dt className="text-mute">Total</dt><dd className="font-semibold">{money(order.total)}</dd>
              <dt className="text-mute">Deliver to</dt><dd>{order.address}</dd>
            </dl>
            <button onClick={close} className="mt-6 w-full rounded-full bg-ink py-3 font-semibold text-white">Done</button>
          </div>
        ) : (
          <form onSubmit={submit} noValidate className="space-y-4">
            <div className="flex items-center justify-between rounded-2xl bg-air p-4 text-sm">
              <span><strong>{PRODUCT.name}</strong><br /><span className="text-mute">{PRODUCT.title}</span></span>
              <span className="text-right"><span className="text-mute">{money(PRODUCT.price)} each</span><br /><strong className="text-lg">{money(total)}</strong></span>
            </div>
            <input name="website" value={f.website} onChange={set("website")} tabIndex={-1} autoComplete="off" aria-hidden="true" className="hidden" />
            <Field id="f-name" label="Full name" error={errors.name}>
              <input id="f-name" className={input} value={f.name} onChange={set("name")} autoComplete="name" aria-invalid={!!errors.name} aria-describedby="f-name-err" />
            </Field>
            <Field id="f-phone" label="Phone number" error={errors.phone} hint="We call to confirm before dispatch.">
              <input id="f-phone" type="tel" inputMode="tel" className={input} value={f.phone} onChange={set("phone")} autoComplete="tel" aria-invalid={!!errors.phone} aria-describedby="f-phone-err" />
            </Field>
            <Field id="f-address" label="Full address" error={errors.address}>
              <textarea id="f-address" rows={3} className={input} value={f.address} onChange={set("address")} autoComplete="street-address" aria-invalid={!!errors.address} aria-describedby="f-address-err" />
            </Field>
            <div className="grid grid-cols-[7rem_1fr] gap-4">
              <Field id="f-quantity" label="Quantity" error={errors.quantity}>
                <input id="f-quantity" type="number" min="1" max={PRODUCT.maxQty} className={input} value={f.quantity} onChange={set("quantity")} aria-invalid={!!errors.quantity} aria-describedby="f-quantity-err" />
              </Field>
              <Field id="f-notes" label="Delivery notes (optional)">
                <input id="f-notes" className={input} value={f.notes} onChange={set("notes")} placeholder="Landmark, preferred time" />
              </Field>
            </div>
            {state === "error" && <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm text-red-800">{msg}</p>}
            <button disabled={state === "loading"} aria-busy={state === "loading"}
              className="w-full rounded-full bg-ink py-4 font-semibold text-white transition disabled:cursor-wait disabled:opacity-60">
              {state === "loading" ? "Placing your order…" : state === "error" ? "Try again" : `Confirm order · ${money(total)}`}
            </button>
            <p className="text-center text-xs text-mute">Pay when we confirm by phone or on delivery. No payment is taken on this page.</p>
          </form>
        )}
      </div>
    </dialog>
  );
}
