const dust = [[-130,-90,0],[120,-110,.8],[-150,20,1.6],[140,40,2.4],[-90,110,3.2],[100,120,4],[-40,-140,2],[60,-150,3.6]];
export default function PurifierArt() {
  return (
    <svg viewBox="-200 -200 400 400" role="img" aria-label="Illustration of the PureAir P1 purifier with dust drifting into it" className="w-full max-w-md">
      <circle r="170" fill="#e3f1f5" /><circle r="115" fill="#c4dccf" opacity=".6" />
      {dust.map(([x, y, d], i) => <circle key={i} r="5" fill="#51636e" className="dust" style={{ "--x": `${x}px`, "--y": `${y}px`, "--d": `${d}s` }} />)}
      <rect x="-48" y="-85" width="96" height="170" rx="40" fill="#10222f" />
      <rect x="-48" y="-85" width="96" height="60" rx="40" fill="#1d3a4d" />
      {[-55,-40,-25,-10].map((y) => <line key={y} x1="-26" x2="26" y1={y} y2={y} stroke="#e3f1f5" strokeWidth="4" strokeLinecap="round" />)}
      <circle cx="0" cy="40" r="9" fill="#f2a33a" /><rect x="-14" y="62" width="28" height="6" rx="3" fill="#51636e" />
    </svg>
  );
}
