"use client";
export default function OrderButton({ children = "Order now", className = "" }) {
  return (
    <button type="button" onClick={() => window.dispatchEvent(new Event("open-order"))}
      className={`rounded-full bg-sun px-7 py-4 font-semibold text-ink shadow-lg shadow-sun/30 transition hover:-translate-y-0.5 hover:brightness-105 active:translate-y-0 ${className}`}>
      {children}
    </button>
  );
}
