# PureAir P1 landing page
1. `npm install`, copy `.env.example` to `.env.local`, fill it in.
2. Google Cloud: enable the Sheets API, create a service account and key; put its `client_email` and `private_key` in env.
3. Create a Sheet with a tab named `Orders`, share it (Editor) with the service account email.
   Header row: Order ID | Date/time | Name | Phone | Address | Quantity | Product | Total | Status | Delivery notes
4. `npm run dev`. Edit price, specs, policy and phone rules in `lib/config.js`. Add real reviews to `REVIEWS`.
5. Deploy (e.g. Vercel) with the same env vars.
